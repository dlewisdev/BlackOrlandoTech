import SwiftUI

struct ContentView: View {
    @State private var originalBill: Double = 0.0
    @State private var costPerPerson: Double = 0.0
    @State private var tipPercentage: Int = 20
    @State private var partySize: Double = 1.0
    let percentages: [Int] = [20, 25, 30, 35]
    
    var body: some View {
        VStack {
            Text("Bill Splitter")
                .font(.largeTitle).bold()
            
            VStack(alignment: .leading) {
                Text("Original Bill: $\(originalBill, specifier: "%.2f")")
                TextField("Enter bill cost", value: $originalBill, format: .currency(code: "USD"))
                    .textFieldStyle(.roundedBorder)
                    .keyboardType(.decimalPad)
            }
            
            VStack(alignment: .leading, spacing: 5) {
                Text("Tip Percentage")
                Picker("Tip Percentage", selection: $tipPercentage) {
                    ForEach(percentages, id: \.self) { percentage in
                        Text("\(percentage)%")
                    }
                }
                .pickerStyle(.segmented)
            }
            
            VStack(alignment: .leading, spacing: 5) {
                Text("Party Size: \(partySize, specifier: "%.f")")
                Slider(value: $partySize, in: 1...6, step: 1)
            }
            
            Button("Calculate") {
                withAnimation {
                    let tipAmount = originalBill * Double(tipPercentage) / 100
                    let totalBill = originalBill + tipAmount
                    costPerPerson = totalBill / partySize
                }
            }
            .buttonStyle(.borderedProminent)
           
        }
        .padding()
    }
}
